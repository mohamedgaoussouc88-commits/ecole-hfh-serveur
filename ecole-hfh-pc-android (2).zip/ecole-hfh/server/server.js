// Serveur École HFH — comptes protégés, droits par rôle appliqués côté serveur. Node.js 18+, aucune dépendance.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,FILE=path.join(__dirname,'data.json'),WWW=path.join(__dirname,'..','www');
let db={rev:0,store:{},users:{}};
try{db=JSON.parse(fs.readFileSync(FILE,'utf8'))}catch(e){}
db.store??={};db.orders??={};db.users??={};db.users.t??={};db.users.p??={};
let timer;const persist=(now)=>{clearTimeout(timer);const w=()=>fs.writeFileSync(FILE,JSON.stringify(db));now?w():timer=setTimeout(w,300)};
// --- mots de passe (scrypt) ---
const mkPw=pw=>{const salt=crypto.randomBytes(16).toString('hex');return{salt,hash:crypto.scryptSync(pw,salt,32).toString('hex')}};
const okPw=(u,pw)=>{if(!u||!u.hash)return false;const h=crypto.scryptSync(pw,u.salt,32),b=Buffer.from(u.hash,'hex');return h.length==b.length&&crypto.timingSafeEqual(h,b)};
const rnd=()=>crypto.randomBytes(5).toString('hex');
const P=k=>{const i=k.indexOf(':');return[k.slice(0,i),k.slice(i+1)]};
const rec=k=>{try{return JSON.parse(db.store[k])}catch(e){return null}};
const lc=s=>String(s||'').trim().toLowerCase();
// --- premier démarrage et migration d'anciennes données ---
const created=[];
function ensureAdmins(){
  for(const [who,login,env] of [['admin','admin','ADMIN_PW'],['founder','fondateur','FOUNDER_PW']]){
    if(db.users[who])continue;
    const old=rec('s:'+(who=='admin'?'adm':'fnd')),pw=process.env[env]||(old&&old.pw)||rnd();
    db.users[who]={login:lc(old&&old.login)||login,...mkPw(pw)};created.push([who=='admin'?'Administrateur':'Fondateur',db.users[who].login,pw])}
  delete db.store['s:adm'];delete db.store['s:fnd'];
  for(const k of Object.keys(db.store)){const[c,id]=P(k);
    if(c=='teachers'||c=='students'){const r=rec(k),f=c=='teachers'?'pw':'ppw',l=c=='teachers'?'login':'plogin',t=c=='teachers'?'t':'p';
      if(r&&(r[f]||r[l])){if(r[l]&&!db.users[t][id])db.users[t][id]={login:lc(r[l]),...(r[f]?mkPw(String(r[f])):{})};delete r[f];db.store[k]=JSON.stringify(r)}}}}
ensureAdmins();
for(const a of process.argv.slice(2)){const w=a=='--reset-admin'?'admin':a=='--reset-founder'?'founder':null;if(w){const pw=rnd();db.users[w]={login:db.users[w]?.login||(w=='admin'?'admin':'fondateur'),...mkPw(pw)};created.push([w=='admin'?'Administrateur':'Fondateur',db.users[w].login,pw])}}
persist(true);
// --- sessions ---
const sess=new Map(),tries=new Map();
const auth=(req,u)=>{const t=(req.headers.authorization||'').replace(/^Bearer /,'')||u.searchParams.get('token');const s=sess.get(t);if(!s||s.exp<Date.now())return null;s.exp=Date.now()+7*864e5;return{...s,token:t}};
// --- droits ---
function view(u,k,v){
  if(u.role=='admin')return v;
  const[c,id]=P(k);
  if(c=='s')return id=='school'?v:undefined;
  if(u.role=='teacher'){
    if(['students','classes','subjects','evals','g','abs'].includes(c))return v;
    if(c=='teachers')return id==u.ref?v:undefined;
    if(c=='slips'){try{return JSON.parse(v).tid==u.ref?v:undefined}catch(e){return}}
    if(c=='msgs')return v;
    if(c=='dm'){try{const m=JSON.parse(v);return m.thread=='t:'+u.ref||m.thread.startsWith('c:')?v:undefined}catch(e){return}}
    return}
  const ch=rec('students:'+u.ref);if(!ch)return;const cl=ch.classId;let r;try{r=JSON.parse(v)}catch(e){r={}}
  if(c=='students'){if(id==u.ref)return v;return r.classId==cl?JSON.stringify({id:r.id,classId:r.classId,name:'—'}):undefined}
  if(c=='classes')return id==cl?v:undefined;
  if(c=='subjects')return v;
  if(c=='evals')return r.classId==cl?v:undefined;
  if(c=='g'){const sid=id.split('_')[1];if(sid==u.ref)return v;const s=rec('students:'+sid);return s&&s.classId==cl?v:undefined}
  if(c=='abs'||c=='pays')return r.sid==u.ref?v:undefined;
  if(c=='msgs')return r.target=='all'||r.target==cl?v:undefined;
  if(c=='dm')return r.thread=='c:'+u.ref?v:undefined;
}
const canWrite=(u,k,v)=>{const[c,id]=P(k);
  if(u.role=='admin')return c!='s'||k=='s:school';
  if(u.role=='teacher')return['evals','g','abs'].includes(c)||(c=='dm'&&(()=>{try{const m=JSON.parse(v);return m.thread.startsWith('c:')||m.thread=='t:'+u.ref}catch(e){return false}})());
  if(u.role=='parent')return c=='dm'&&(()=>{try{return JSON.parse(v).thread=='c:'+u.ref}catch(e){return false}})();
  return false};
const filt=(u,ops)=>ops.map(o=>o.v===null?o:(v=>v===undefined?null:{k:o.k,v})(view(u,o.k,o.v))).filter(Boolean);
// --- application des opérations (avec extraction des mots de passe) ---
function applyOp(o,warn){
  const[c,id]=P(o.k);
  if(o.v===null){delete db.store[o.k];if(c=='teachers')delete db.users.t[id];if(c=='students')delete db.users.p[id];return o}
  if(c=='teachers'||c=='students'){
    let r;try{r=JSON.parse(o.v)}catch(e){return null}
    const f=c=='teachers'?'pw':'ppw',l=c=='teachers'?'login':'plogin',t=c=='teachers'?'t':'p',login=lc(r[l]),pw=r[f]?String(r[f]):'';
    delete r[f];
    if(!login){delete db.users[t][id]}
    else{
      const dup=[db.users.admin,db.users.founder,...Object.entries(db.users.t).filter(([i])=>!(t=='t'&&i==id)).map(x=>x[1]),...Object.entries(db.users.p).filter(([i])=>!(t=='p'&&i==id)).map(x=>x[1])].some(x=>x&&x.login==login);
      if(dup){warn.push('Identifiant « '+login+' » déjà utilisé : modification refusée.');return null}
      const cur=db.users[t][id]||{};
      if(pw&&pw.length<6){warn.push('Mot de passe trop court (6 caractères minimum) : non modifié.')}
      db.users[t][id]={...cur,login,...(pw&&pw.length>=6?mkPw(pw):{})}}
    o={k:o.k,v:JSON.stringify(r)}}
  db.store[o.k]=o.v;return o}
// --- Orange Money (Web Payment) ---
let CFG={};try{CFG=JSON.parse(fs.readFileSync(path.join(__dirname,'config.json'),'utf8')).orange||{}}catch(e){}
{const E=process.env,c=CFG;CFG={mode:E.OM_MODE||c.mode||'off',clientId:E.OM_CLIENT_ID||c.clientId||'',clientSecret:E.OM_CLIENT_SECRET||c.clientSecret||'',authHeader:E.OM_AUTH_HEADER||c.authHeader||'',merchantKey:E.OM_MERCHANT_KEY||c.merchantKey||'',
  baseUrl:E.OM_BASE_URL||c.baseUrl||'https://api.orange.com/orange-money-webpay/dev/v1',tokenUrl:E.OM_TOKEN_URL||c.tokenUrl||'https://api.orange.com/oauth/v3/token',currency:E.OM_CURRENCY||c.currency||'OUV',publicUrl:(E.PUBLIC_URL||c.publicUrl||'').replace(/\/$/,''),lang:c.lang||'fr'};
  if(CFG.mode=='mock'){CFG.baseUrl='http://localhost:'+PORT+'/mock/orange-money-webpay/dev/v1';CFG.tokenUrl='http://localhost:'+PORT+'/mock/oauth/v3/token';CFG.merchantKey='MOCK';CFG.authHeader='bW9jazptb2Nr'}}
let omTok={v:'',exp:0};
async function omToken(){if(omTok.exp>Date.now())return omTok.v;const h=CFG.authHeader||Buffer.from(CFG.clientId+':'+CFG.clientSecret).toString('base64');
  const r=await fetch(CFG.tokenUrl,{method:'POST',headers:{Authorization:'Basic '+h,'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});
  if(!r.ok)throw new Error('jeton Orange refusé ('+r.status+')');const j=await r.json();omTok={v:j.access_token,exp:Date.now()+Math.max(60,(+j.expires_in||3600)-300)*1000};return omTok.v}
async function omPost(p,b){const t=await omToken();const r=await fetch(CFG.baseUrl+p,{method:'POST',headers:{Authorization:'Bearer '+t,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(b)});
  const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error('Orange '+p+' '+r.status+' '+JSON.stringify(j).slice(0,200));return j}
function balance(sid){const s=rec('students:'+sid);if(!s)return null;const c=rec('classes:'+s.classId)||{},sc=rec('s:school')||{},ins=(s.insc||'Inscription')=='Réinscription'?+sc.fr:+sc.fi;
  let paid=0;for(const k in db.store)if(k.startsWith('pays:')){const x=rec(k);if(x&&x.sid==sid)paid+=+x.amount||0}return(+c.fee||0)+(ins||0)-paid}
async function settle(id){const o=db.orders[id];if(!o||o.status!='PENDING')return o;
  const r=await omPost('/transactionstatus',{order_id:id,amount:o.amount,pay_token:o.pay_token}),st=String(r.status||'').toUpperCase();
  if(st=='SUCCESS'&&o.status=='PENDING'){o.status='SUCCESS';o.txn=r.txnid||'';
    const op={k:'pays:om_'+id,v:JSON.stringify({id:'om_'+id,sid:o.sid,amount:o.amount,date:new Date().toISOString().slice(0,10),note:'Orange Money'+(o.txn?' · '+o.txn:'')})};
    db.store[op.k]=op.v;db.rev++;for(const[c,x]of clients){const f=filt(x,[op]);if(f.length)c.write('data: '+JSON.stringify({rev:db.rev,cid:'srv',ops:f})+'\n\n')}}
  else if(['FAILED','EXPIRED','CANCELLED'].includes(st))o.status=st;
  persist();return o}
const mock={};
// --- serveur HTTP ---
const clients=new Map(),MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.png':'image/png','.webmanifest':'application/manifest+json'};
const body=req=>new Promise((ok,ko)=>{let b='';req.on('data',d=>{b+=d;if(b.length>30e6){req.destroy();ko()}});req.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch(e){ko(e)}})});
http.createServer(async(req,res)=>{
  const u=new URL(req.url,'http://x'),H={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Allow-Methods':'GET,POST,OPTIONS'},J=(n,o)=>{res.writeHead(n,{...H,'Content-Type':'application/json'});res.end(JSON.stringify(o))};
  try{
  if(req.method=='OPTIONS'){res.writeHead(204,H);return res.end()}
  if(u.pathname=='/api/ping')return J(200,{ok:1});
  if(CFG.mode=='mock'&&u.pathname.startsWith('/mock/')){
    if(u.pathname=='/mock/oauth/v3/token')return J(200,{token_type:'Bearer',access_token:'mock',expires_in:'7776000'});
    if(u.pathname.endsWith('/webpayment')){const b=await body(req),pt='MP'+rnd();mock[pt]={...b,pay_token:pt,notif_token:'NT'+rnd(),status:'INITIATED'};return J(201,{status:201,message:'OK',pay_token:pt,payment_url:(CFG.publicUrl||'http://localhost:'+PORT)+'/mock/pay?t='+pt,notif_token:mock[pt].notif_token})}
    if(u.pathname.endsWith('/transactionstatus')){const b=await body(req),t=mock[b.pay_token];if(!t)return J(404,{});return J(200,{status:t.status,order_id:t.order_id,txnid:t.txnid||''})}
    if(u.pathname=='/mock/pay'){const t=mock[u.searchParams.get('t')];if(!t){res.writeHead(404);return res.end('?')}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});
      return res.end('<meta name=viewport content="width=device-width"><body style="font-family:sans-serif;max-width:380px;margin:40px auto;padding:16px"><h2 style="color:#f60">Orange Money (simulation)</h2><p>Paiement de <b>'+(+t.amount)+' '+String(t.currency).replace(/[^A-Z]/g,'')+'</b><br>Commande '+String(t.order_id).replace(/[^\w]/g,'')+'</p><p><a id=ok href="/mock/pay/do?ok=1&t='+t.pay_token+'" style="display:block;background:#f60;color:#fff;padding:12px;text-align:center;border-radius:6px;text-decoration:none">Valider le paiement</a></p><p><a id=no href="/mock/pay/do?ok=0&t='+t.pay_token+'">Annuler</a></p></body>')}
    if(u.pathname=='/mock/pay/do'){const t=mock[u.searchParams.get('t')];if(!t){res.writeHead(404);return res.end('?')}const ok=u.searchParams.get('ok')=='1';t.status=ok?'SUCCESS':'FAILED';t.txnid='MP'+rnd();
      if(ok)fetch(t.notif_url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'SUCCESS',notif_token:t.notif_token,txnid:t.txnid})}).catch(()=>{});res.writeHead(302,{Location:ok?t.return_url:t.cancel_url});return res.end()}}
  if(u.pathname=='/api/pay/notify'&&req.method=='POST'){const b=await body(req),id=Object.keys(db.orders).find(k=>db.orders[k].notif_token&&db.orders[k].notif_token===b.notif_token);if(id)settle(id).catch(e=>console.log('Orange notif :',e.message));return J(200,{ok:1})}
  if(u.pathname=='/api/login'&&req.method=='POST'){
    const b=await body(req),key=(req.socket.remoteAddress||'')+'|'+b.role+'|'+lc(b.login),tr=tries.get(key)||{n:0,t:Date.now()};
    if(Date.now()-tr.t>6e5){tr.n=0;tr.t=Date.now()}
    if(tr.n>=10)return J(429,{error:'Trop de tentatives. Réessayez dans 10 minutes.'});
    const login=lc(b.login),pw=String(b.password||'');let user=null,rf=null;
    if(b.role=='admin'||b.role=='founder'){const a=db.users[b.role];if(a&&a.login==login&&okPw(a,pw))user={role:'admin',name:b.role=='admin'?'Administrateur':'Fondateur'}}
    else{const t=b.role=='teacher'?'t':b.role=='parent'?'p':null;if(t){const e=Object.entries(db.users[t]).find(([i,x])=>x.login==login&&okPw(x,pw));if(e){const r=rec((t=='t'?'teachers:':'students:')+e[0]);
      user=t=='t'?{role:'teacher',name:r?.name||'Enseignant',tid:e[0]}:{role:'parent',name:r?.parent||'Parent',sid:e[0]};rf=e[0]}}}
    if(!user){tr.n++;tries.set(key,tr);return J(401,{error:'Identifiant ou mot de passe incorrect.'})}
    tries.delete(key);const token=crypto.randomBytes(24).toString('hex');sess.set(token,{role:user.role,ref:rf,exp:Date.now()+7*864e5});return J(200,{token,user})}
  if(u.pathname.startsWith('/api/')){
    const s=auth(req,u);if(!s)return J(401,{error:'Session expirée.'});
    if(u.pathname=='/api/logout'){sess.delete(s.token);const c=[...clients].find(([r,x])=>x.token==s.token);if(c){c[0].end();clients.delete(c[0])}return J(200,{ok:1})}
    if(u.pathname=='/api/all'){const st={};for(const k in db.store){const v=view(s,k,db.store[k]);if(v!==undefined)st[k]=v}return J(200,{rev:db.rev,store:st})}
    if(u.pathname=='/api/stream'){res.writeHead(200,{...H,'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});res.write('retry: 3000\n\n');
      clients.set(res,s);const ka=setInterval(()=>res.write(': ka\n\n'),20000);req.on('close',()=>{clients.delete(res);clearInterval(ka)});return}
    if(u.pathname=='/api/ops'&&req.method=='POST'){
      const b=await body(req),warn=[],ok=[];
      for(const o of(b.ops||[])){if(typeof o.k!='string'||!(o.v===null||typeof o.v=='string'))continue;
        if(!canWrite(s,o.k,o.v)){warn.push('Modification non autorisée pour votre profil.');continue}
        const r=applyOp(o,warn);if(r)ok.push(r)}
      if(ok.length){db.rev++;persist();
        for(const[c,x]of clients){const f=filt(x,ok);if(f.length)c.write('data: '+JSON.stringify({rev:db.rev,cid:b.cid,ops:f})+'\n\n')}}
      return J(200,{rev:db.rev,warn:[...new Set(warn)]})}
    if(u.pathname=='/api/account'&&req.method=='POST'){
      if(s.role!='admin')return J(403,{error:'Réservé à l’administrateur.'});
      const b=await body(req),w=b.who=='founder'?'founder':'admin',a=db.users[w];
      if(b.pw&&String(b.pw).length<6)return J(400,{error:'Mot de passe : 6 caractères minimum.'});
      if(b.login){const l=lc(b.login),dup=[db.users.admin,db.users.founder,...Object.values(db.users.t),...Object.values(db.users.p)].some(x=>x&&x!==a&&x.login==l);if(dup)return J(400,{error:'Identifiant déjà utilisé.'});a.login=l}
      if(b.pw)Object.assign(a,mkPw(String(b.pw)));persist();return J(200,{ok:1})}
    if(u.pathname=='/api/pay/config')return J(200,{enabled:CFG.mode!='off'});
    if(u.pathname=='/api/pay/orange'&&req.method=='POST'){
      if(CFG.mode=='off')return J(400,{error:'Le paiement Orange Money n’est pas activé.'});
      const b=await body(req),sid=String(b.sid||''),amt=Math.round(+b.amount);
      if(s.role=='teacher'||(s.role=='parent'&&s.ref!=sid))return J(403,{error:'Non autorisé.'});
      const bal=balance(sid);if(bal===null)return J(404,{error:'Élève introuvable.'});
      if(!(amt>0)||amt>bal)return J(400,{error:'Montant invalide (solde à payer : '+Math.max(0,bal)+' FG).'});
      const order='HFH'+Date.now().toString(36)+crypto.randomBytes(3).toString('hex'),pu=CFG.publicUrl||('http://'+req.headers.host);
      try{const r=await omPost('/webpayment',{merchant_key:CFG.merchantKey,currency:CFG.currency,order_id:order,amount:amt,return_url:pu+'/?pay='+order,cancel_url:pu+'/?paycancel='+order,notif_url:pu+'/api/pay/notify',lang:CFG.lang,reference:'Frais scolaires'});
        if(!r.payment_url)throw new Error('réponse sans payment_url');
        db.orders[order]={sid,amount:amt,status:'PENDING',pay_token:r.pay_token,notif_token:r.notif_token,created:Date.now(),by:s.role};persist();return J(200,{order,payment_url:r.payment_url})}
      catch(e){console.log('Orange Money :',e.message);return J(502,{error:'Orange Money indisponible pour le moment. Réessayez plus tard.'})}}
    if(u.pathname=='/api/pay/status'){const id=u.searchParams.get('order'),o=db.orders[id];if(!o||(s.role=='parent'&&s.ref!=o.sid))return J(404,{error:'Commande introuvable.'});
      let r=o;if(o.status=='PENDING'){try{r=(await settle(id))||o}catch(e){console.log('Orange statut :',e.message)}}return J(200,{status:r.status,amount:r.amount})}
    return J(404,{error:'?'})}
  let f=path.join(WWW,decodeURIComponent(u.pathname=='/'?'/index.html':u.pathname));
  if(!f.startsWith(WWW)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Introuvable')}
  res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(res);
  }catch(e){try{J(400,{error:'Requête invalide.'})}catch(_){}}
}).listen(PORT,()=>{
  const ips=[].concat(...Object.values(require('os').networkInterfaces())).filter(i=>i.family=='IPv4'&&!i.internal).map(i=>i.address);
  console.log('\n=== École HFH : serveur démarré ===');
  created.forEach(([n,l,p])=>console.log('COMPTE CRÉÉ — '+n+' : identifiant « '+l+' », mot de passe « '+p+' » (notez-le et changez-le dans l\'application)'));
  console.log('Paiement Orange Money : '+(CFG.mode=='off'?'désactivé (voir config.json)':CFG.mode=='mock'?'MODE SIMULATION (aucun vrai argent)':'activé ('+CFG.mode+')'));
  console.log('Sur cet ordinateur : http://localhost:'+PORT);
  ips.forEach(ip=>console.log('Autres appareils (même Wi-Fi) : http://'+ip+':'+PORT));
  console.log('Laissez cette fenêtre ouverte.\n')});
