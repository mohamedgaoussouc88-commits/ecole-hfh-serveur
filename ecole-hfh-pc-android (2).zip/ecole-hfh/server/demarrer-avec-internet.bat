@echo off
cd /d %~dp0
echo === Ecole HFH : demarrage avec acces internet (ngrok) ===
echo.
start "Serveur Ecole HFH" cmd /k node server.js
timeout /t 3 >nul
echo Ouverture du tunnel internet...
ngrok http --domain=VOTRE-DOMAINE.ngrok-free.app 3000
pause
