#!/bin/bash
cd "$(dirname "$0")"
echo "=== École HFH : démarrage avec accès internet (ngrok) ==="
node server.js &
SRVPID=$!
sleep 2
ngrok http --domain=VOTRE-DOMAINE.ngrok-free.app 3000
kill $SRVPID
