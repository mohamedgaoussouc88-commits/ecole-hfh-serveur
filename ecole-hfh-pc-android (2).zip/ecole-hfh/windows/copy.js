const fs=require('fs'),path=require('path');
fs.rmSync(path.join(__dirname,'www'),{recursive:true,force:true});
fs.cpSync(path.join(__dirname,'..','www'),path.join(__dirname,'www'),{recursive:true});
console.log('Fichiers de l\'application copiés.');
