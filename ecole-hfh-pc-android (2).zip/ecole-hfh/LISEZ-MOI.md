# École HFH — installation PC et Android

Le dossier `www` contient l'application complète. Elle fonctionne sans internet une fois installée.
Les données restent sur l'appareil où l'application est utilisée : PC et téléphone ne partagent pas leurs données
(utilisez l'onglet « Sauvegarde » pour copier les données d'un appareil à l'autre).

## Méthode 1 (la plus simple) : installer depuis le navigateur — PC et Android

1. Mettez le dossier `www` en ligne gratuitement :
   - allez sur https://app.netlify.com/drop, glissez-déposez le dossier `www` ; vous obtenez une adresse en https:// ;
   - (ou utilisez GitHub Pages, si vous connaissez).
2. **Android** : ouvrez l'adresse dans Chrome, menu ⋮, « Installer l'application » (ou « Ajouter à l'écran d'accueil »).
3. **PC (Windows/Mac)** : ouvrez l'adresse dans Chrome ou Edge, cliquez sur l'icône « Installer » dans la barre d'adresse.
4. L'application apparaît avec son icône, s'ouvre en plein écran et fonctionne hors ligne. Connexion : admin / admin.

## Méthode 2 : vrai fichier .exe pour Windows (dossier `windows`)

Sur un PC Windows avec Node.js (https://nodejs.org) installé, dans le dossier `windows` :

    npm install
    npm run dist

L'installateur `École HFH Setup 1.0.0.exe` apparaît dans `windows/dist`. Pour simplement tester : `npm start`.

## Méthode 3 : fichier .apk pour Android

1. Faites d'abord la méthode 1 pour obtenir l'adresse https:// de l'application.
2. Allez sur https://www.pwabuilder.com, collez l'adresse, cliquez sur « Package for stores » puis « Android ».
3. Téléchargez l'APK, copiez-le sur le téléphone et installez-le (autorisez les « sources inconnues »).

## Mettre à jour

Remplacez les fichiers du dossier `www` par la nouvelle version et mettez-les de nouveau en ligne ;
les appareils se mettent à jour à la prochaine ouverture avec internet. Les données sont conservées.

---

## Serveur de l'école : comptes protégés et synchronisation en direct

Le dossier `server` relie tous les appareils. Chaque personne se connecte avec **son propre compte**, et le serveur ne
lui envoie que ce que son profil a le droit de voir. Les modifications de l'administrateur apparaissent en quelques secondes.

| Profil | Voit | Peut modifier |
|---|---|---|
| Administrateur / Fondateur | tout | tout |
| Enseignant | élèves, classes, matières, évaluations, notes, absences, sa fiche et ses bulletins de paie | évaluations, notes, absences |
| Parent | son enfant (notes, absences, paiements, carte). Les camarades de classe apparaissent sans nom, pour le classement | rien |

Les mots de passe sont stockés chiffrés (scrypt) sur le serveur et ne sont jamais renvoyés aux appareils.

### Installation (une seule fois)
1. Sur un ordinateur de l'école, installez Node.js (https://nodejs.org, version 18 ou plus).
2. Double-cliquez sur `server/demarrer-serveur.bat` (Windows) ou lancez `node server/server.js`.
3. Au **premier démarrage**, la fenêtre affiche les mots de passe créés pour l'administrateur (`admin`) et le fondateur
   (`fondateur`). Notez-les, puis changez-les dans l'onglet École. Laissez la fenêtre ouverte.
4. La fenêtre affiche aussi les adresses, par exemple `http://192.168.1.10:3000`.

### Connecter les appareils
1. Sur chaque appareil (même Wi-Fi), ouvrez l'adresse du serveur dans le navigateur : l'application se relie toute seule.
   Sinon : écran de connexion, « Serveur de synchronisation », saisir l'adresse.
2. **Première connexion, sur l'appareil de l'administrateur** : si cet appareil contenait déjà des données (mode local),
   elles sont envoyées au serveur. Les mots de passe des enseignants et des parents déjà saisis sont chiffrés à ce moment.
   Attention : sur un serveur qui contient déjà des données, les données locales de l'appareil sont remplacées.
3. Créez ensuite les comptes : dans la fiche d'un enseignant ou d'un élève, renseignez l'identifiant et le mot de passe
   (6 caractères minimum). Laisser le mot de passe vide lors d'une modification le conserve. Deux comptes ne peuvent pas
   avoir le même identifiant.
4. Les enseignants et les parents se connectent avec leur profil et leurs identifiants. Voyant 🟢 en haut : synchronisé.

### Bon à savoir
- **Mot de passe administrateur oublié** : sur l'ordinateur du serveur, lancez `node server/server.js --reset-admin`
  (ou `--reset-founder`) ; un nouveau mot de passe s'affiche.
- **Trop de tentatives** : après 10 essais ratés, la connexion est bloquée 10 minutes.
- **Sessions** : elles durent 7 jours d'activité ; un redémarrage du serveur oblige à se reconnecter.
- **Hors connexion**, les modifications sont gardées puis envoyées au retour du réseau (tant qu'on ne se déconnecte pas).
- Si deux personnes modifient la même fiche en même temps, la dernière modification l'emporte.
- **Sauvegarde** : copiez régulièrement `server/data.json` (toutes les données et les mots de passe chiffrés).
- **Accès depuis l'extérieur** : hébergez le dossier sur un serveur en ligne avec HTTPS (VPS, Render, Railway...) ;
  n'ouvrez pas le serveur de l'école directement sur internet sans HTTPS. Sur le Wi-Fi de l'école, `http://` suffit.
- L'installation comme application (PWA) sur téléphone demande HTTPS ; en `http://` sur le Wi-Fi, utilisez le navigateur.

---

## Paiement des frais par Orange Money

Les parents peuvent payer le solde de leur enfant depuis l'application (onglet « Mon enfant », bouton
« 📱 Payer par Orange Money »). Le paiement est ensuite enregistré automatiquement dans les frais, et l'administrateur
le voit en direct. Le montant maximum est le solde restant ; le serveur le vérifie.

### Comment ça marche
1. Le parent choisit le montant : il est redirigé vers la page sécurisée d'Orange Money.
2. Il génère un code temporaire (OTP) avec le service USSD Orange Money de son téléphone, le saisit et valide.
3. Orange prévient le serveur de l'école, qui **vérifie lui-même** le résultat auprès d'Orange avant d'enregistrer le paiement
   (une fausse notification est sans effet). Le parent revient dans l'application, qui affiche « Paiement reçu ».

### Ce qu'il faut obtenir auprès d'Orange (pas fourni par l'application)
- Le statut de **marchand Orange Money** (dossier KYA à déposer dans une boutique Orange de Guinée). L'API « Orange Money
  Web Payment » est réservée aux marchands ; elle est disponible en Guinée (Conakry) et cite les frais de scolarité.
- Un compte sur https://developer.orange.com et l'abonnement à l'API « Orange Money Web Payment ».
- Les identifiants fournis : `client_id` et `client_secret` (ou l'en-tête d'autorisation), et la `merchant_key`.
- Dans la documentation Orange reçue avec le contrat : l'**adresse de l'API de production pour la Guinée** et le **code de
  la monnaie** (GNF). Ces deux valeurs ne sont pas publiques ; les valeurs par défaut du fichier correspondent au bac à sable
  (`OUV`) et sont à remplacer.

### Configuration
1. Copiez `server/config.example.json` en `server/config.json` et remplissez la partie `orange` (`mode` : `sandbox`
   pour les essais Orange, puis `production`).
2. `publicUrl` : l'adresse HTTPS publique du serveur (par exemple https://ecole.exemple.com). Orange doit pouvoir la joindre
   pour notifier les paiements, et les parents doivent pouvoir l'ouvrir depuis chez eux. Sur le seul Wi-Fi de l'école,
   les paiements peuvent aboutir (le serveur interroge Orange lui-même), mais le retour dans l'application ne marche
   que pour les appareils connectés à ce Wi-Fi.
3. Relancez le serveur. La fenêtre indique « Paiement Orange Money : activé ».

### Essayer sans compte Orange
Lancez le serveur avec `OM_MODE=mock` (Windows : `set OM_MODE=mock` puis `node server/server.js`). Une fausse page « Orange
Money » (simulation, sans argent) permet de tester tout le parcours : paiement, annulation, montant refusé.

### Bon à savoir
- Les frais de l'opérateur (commission marchand) sont fixés par votre contrat avec Orange ; l'application ne les ajoute pas.
- Vérifiez chaque paiement dans votre espace marchand Orange lors des premières semaines.
- Le remboursement d'un paiement se fait chez Orange ; supprimez ensuite la ligne dans l'onglet « Frais » de l'application.

---

## Communication : annonces et messagerie

Un onglet **💬 Communication** est disponible pour l'administrateur, le fondateur, les enseignants et les parents.

### Annonces
- Seuls l'administrateur et le fondateur peuvent publier une annonce, avec un titre, un message et des destinataires :
  tout le monde, les enseignants seulement, ou une classe précise.
- Les enseignants voient toutes les annonces. Un parent ne voit que celles adressées à tout le monde ou à la classe
  de son enfant.

### Messagerie
- **Parent** : un seul fil de discussion avec l'école, au sujet de son enfant. L'administrateur et les enseignants
  peuvent y répondre.
- **Enseignant** : peut écrire dans le fil de n'importe quel élève (en le choisissant dans une liste), et dispose
  d'un fil séparé avec l'administration pour ses propres questions (salaire, organisation...).
- **Administrateur / Fondateur** : voit et peut écrire dans tous les fils, choisis dans une liste (par élève ou par
  enseignant).
- Sans serveur (mode local), la messagerie fonctionne aussi, mais reste sur l'appareil : elle prend tout son sens
  avec le serveur de synchronisation, pour que les messages arrivent en direct chez les autres.
- Le serveur applique ces règles lui-même : un parent ne peut ni lire ni écrire dans le fil d'un autre élève, et
  seuls l'administrateur et le fondateur peuvent publier une annonce.

---

## Rendre le serveur accessible depuis internet (sur votre propre ordinateur)

Par défaut, le serveur n'est joignable que sur le Wi-Fi de l'école. Pour que des appareils ailleurs (autre Wi-Fi,
réseau mobile) reçoivent les mêmes informations en direct, il faut lui donner une adresse internet permanente.
La méthode la plus simple, sans toucher à votre routeur ni connaître votre adresse IP, s'appelle un **tunnel** :
un petit programme (ngrok) ouvre un passage sécurisé entre votre ordinateur et internet.

### Installation (une seule fois)
1. Créez un compte gratuit sur https://dashboard.ngrok.com/signup.
2. Installez ngrok en suivant https://dashboard.ngrok.com/get-started/setup (Windows, Mac ou Linux).
3. Dans le tableau de bord ngrok, menu **Cloud Edge → Domains**, cliquez sur **Create Domain** pour obtenir un
   domaine fixe et gratuit, du type `votre-ecole.ngrok-free.app`. Il restera toujours le même.
4. Ouvrez `server/demarrer-avec-internet.bat` (Windows) ou `demarrer-avec-internet.sh` (Mac/Linux) avec un
   éditeur de texte, et remplacez `VOTRE-DOMAINE.ngrok-free.app` par le domaine obtenu à l'étape 3.

### Utilisation au quotidien
1. Double-cliquez sur `server/demarrer-avec-internet.bat` (ou lancez le `.sh`). Deux fenêtres s'ouvrent : le
   serveur de l'école, et le tunnel internet. **Laissez les deux ouvertes** et l'ordinateur allumé et connecté
   à internet.
2. Tous les appareils (administrateur, fondateur, enseignants, parents), où qu'ils soient, se connectent avec
   l'adresse **https://votre-ecole.ngrok-free.app** — la même partout, à la maison comme à l'école.
3. Au premier essai, ngrok affiche une page d'avertissement (« ngrok tunnel ») avant d'ouvrir l'application :
   c'est normal sur le compte gratuit, cliquez sur « Visit Site ».

### Bon à savoir
- **L'ordinateur doit rester allumé** pour que les autres appareils reçoivent les données. S'il s'éteint ou perd
  internet, l'application repasse en mode local le temps de la coupure, sans perte de données.
- **HTTPS est automatique** avec ngrok : le paiement par Orange Money peut donc aussi fonctionner avec cette adresse
  (indiquez-la comme `publicUrl` dans `server/config.json`, voir plus haut).
- Le compte ngrok gratuit limite le nombre d'appareils connectés en même temps sur le plan gratuit actuel ; au-delà,
  ngrok propose un abonnement payant. Vérifiez les limites en vigueur sur votre compte ngrok si l'école grandit.
- Alternative professionnelle, sans dépendre d'un ordinateur qui doit rester allumé : héberger `server` chez un
  hébergeur en ligne (Render, Railway...), comme évoqué précédemment. Dites-le si vous voulez ces étapes à la place.
